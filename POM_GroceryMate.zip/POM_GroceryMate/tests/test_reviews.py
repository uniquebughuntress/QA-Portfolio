# -*- coding: utf-8 -*-
# tests/test_reviews.py
# Erstellt: 27.07.26 um 12:19
# Autor: natalya
# Projekt: QA-Portfolio
"""Review tests for GroceryMate."""

from POM_GroceryMate.pages import store_page
from POM_GroceryMate.pages.home_page import HomePage
from POM_GroceryMate.utils.constants import ProductPageLocators
import time


def test_create_star_only_review(logged_in_driver):
    """Verify that a user can submit a star-only review."""
    home_page = HomePage(logged_in_driver)
    store_page = home_page.go_to_shop()

    product_page = store_page.search_product("Cherries")

    assert product_page.get_title() == "Cherries"
    assert product_page.is_review_ui_displayed()

    initial_count = product_page.get_review_count()

    try:
        product_page.select_stars(3)
        product_page.send_review()

        final_count = product_page.wait_for_review_count_change(
            initial_count,
        )

        assert final_count == initial_count + 1
        assert product_page.get_first_author() == "Testina1"
        assert product_page.get_first_rating() == 3
        assert product_page.get_first_text() == ""

    finally:
        product_page.open_menu()
        product_page.click_delete()
        assert product_page.accept_alert()


def test_delete_own_review(logged_in_driver):
    """Verify that a user can delete their own review."""
    home_page = HomePage(logged_in_driver)
    store_page = home_page.go_to_shop()

    product_page = store_page.search_product("Loose Pears")

    initial_count = product_page.get_review_count()

    product_page.select_stars(3)
    product_page.send_review()

    created_count = product_page.wait_for_review_count_change(
        initial_count,
    )

    assert created_count == initial_count + 1
    assert product_page.get_first_author() == "Testina1"
    assert product_page.get_first_rating() == 3

    product_page.open_menu()
    product_page.click_delete()

    assert product_page.accept_alert()

    deleted_count = product_page.wait_for_review_count_change(
        created_count,
    )

    assert deleted_count == initial_count


# def test_second_review_is_restricted_mango(logged_in_driver):
#     """Verify that a user cannot review the same product twice."""
#     home_page = HomePage(logged_in_driver)
#     store_page = home_page.go_to_shop()
#
#     product_page = store_page.search_product("Loose Mango")
#     print("URL:", product_page.driver.current_url)
#
#     print(
#         "Restriction:",
#         len(
#             product_page.driver.find_elements(
#                 *ProductPageLocators.REVIEW_RESTRICTION,
#             )
#         ),
#     )
#
#     print(
#         "Textarea:",
#         len(
#             product_page.driver.find_elements(
#                 *ProductPageLocators.REVIEW_TEXTAREA,
#             )
#         ),
#     )
#
#     assert product_page.get_title() == "Loose Mango"
#     assert not product_page.is_review_ui_displayed()
#     assert product_page.is_restriction_displayed()
#     assert (
#         product_page.get_restriction_text() == "You have already reviewed this product."
#     )
#     # restriction_elements = product_page.driver.find_elements(
#     #     *ProductPageLocators.REVIEW_RESTRICTION,
#     # )
#     #
#     # print("Restriction count:", len(restriction_elements))
#     #
#     # if restriction_elements:
#     #     restriction = restriction_elements[0]
#     #
#     #     print("Restriction HTML:")
#     #     print(restriction.get_attribute("outerHTML"))
#     #
#     #     print("Displayed:", restriction.is_displayed())
#
#
# # def test_second_review_is_restricted(logged_in_driver):
# #     """Verify that a user cannot review the same product twice."""
# #     home_page = HomePage(logged_in_driver)
# #     store_page = home_page.go_to_shop()
# #
# #     product_page = store_page.search_product("Loose Mango")
# #
# #     assert product_page.get_title() == "Loose Mango"
# #
# #     print("Review UI:", product_page.is_review_ui_displayed())
# #     print("Restriction:", product_page.is_restriction_displayed())
# #     print("Restriction text:", product_page.get_restriction_text())
#
#
# def test_second_review_is_restricted_cherries(logged_in_driver):
#     """Verify that a user cannot review the same product twice."""
#     home_page = HomePage(logged_in_driver)
#     store_page = home_page.go_to_shop()
#
#     product_page = store_page.search_product("Cherries")
#     print("URL:", product_page.driver.current_url)
#
#     print(
#         "Restriction:",
#         len(
#             product_page.driver.find_elements(
#                 *ProductPageLocators.REVIEW_RESTRICTION,
#             )
#         ),
#     )
#
#     print(
#         "Textarea:",
#         len(
#             product_page.driver.find_elements(
#                 *ProductPageLocators.REVIEW_TEXTAREA,
#             )
#         ),
#     )
#
#     assert product_page.get_title() == "Cherries"
#     assert not product_page.is_review_ui_displayed()
#     assert product_page.is_restriction_displayed()
#     assert (
#         product_page.get_restriction_text() == "You have already reviewed this product."
#     )


def test_review_restriction_after_creation(logged_in_driver):
    """Verify that the review form is restricted after submitting a review."""
    home_page = HomePage(logged_in_driver)
    store_page = home_page.go_to_shop()

    product_page = store_page.search_product("Cherries")

    print("\n=== REVIEW RESTRICTION CHECK ===")
    print("Product:", product_page.get_title())
    print(
        "Review UI before:",
        product_page.is_review_ui_displayed(),
    )

    initial_count = product_page.get_review_count()
    print("Initial review count:", initial_count)

    product_page.select_stars(3)
    product_page.send_review()

    final_count = product_page.wait_for_review_count_change(
        initial_count,
    )

    # print("Final review count:", final_count)
    # print(
    #     "Review UI after:",
    #     product_page.is_review_ui_displayed(),
    # )
    # print(
    #     "Restriction after:",
    #     product_page.is_restriction_displayed(),
    # )
    # print(
    #     "Restriction text:",
    #     product_page.get_restriction_text(),
    # )
    # print("===============================\n")

    assert final_count == initial_count + 1
    assert not product_page.is_review_ui_displayed()
    assert product_page.is_restriction_displayed()
    assert (
        product_page.get_restriction_text() == "You have already reviewed this product."
    )
